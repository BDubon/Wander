# Group Project Proposal


### INST326 
***Run the program from PAPP.py***

### Group Members
- Nicholas Archer
- Byron Cantillano
- Bryan Dubón
- Nicolas Fuster

### Summary
Our group is planning to build a web scraper to gather data about products offered on Amazon.com. 
We intend to periodically track and collect data so the end user can track price changes over time.
We also plan on offering a graphical user interface (GUI) where the user will easily be able to paste a
product’s url and visually compare the compiled data for such product.

### Project Goals	
- Successfully request web pages
- Collect data elements from web pages
- Store collected data for future usage
- Design and create GUI
- Display collected data in a table format
- Display data in a graphical format (line graph)
- Perform Data Analytics to collected data
- Derive insight through data analytics 


